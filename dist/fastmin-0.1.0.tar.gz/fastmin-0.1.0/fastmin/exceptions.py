class EmptyArray(Exception):
    pass