# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['fastmin']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'fastmin',
    'version': '0.1.0',
    'description': 'This a Python package that find the minimum in array which has first few elements are strictly monotonically decreasing, the remaining elements are strictly monotonically increasing. ',
    'long_description': None,
    'author': 'Sundara Nataraja',
    'author_email': 'sundaranatarajaa@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.6,<4.0',
}


setup(**setup_kwargs)
